import tensorflow as tf

tf.config.list_physical_devices('GPU')
